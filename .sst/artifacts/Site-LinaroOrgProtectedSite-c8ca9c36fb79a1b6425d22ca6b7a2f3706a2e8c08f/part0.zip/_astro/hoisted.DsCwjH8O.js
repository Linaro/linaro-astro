import{_ as a}from"./preload-helper.ygWHROA3.js";const{signIn:e,signOut:n}=await a(()=>import("./client.BqElmF-z.js"),[]),t=new URLSearchParams(window.location.search);document.readyState!=="loading"?e("spire"):document.addEventListener("DOMContentLoaded",function(){e("spire",{redirect:!0,callbackUrl:t.get("callbackUrl")||"/"})});
//# sourceMappingURL=hoisted.DsCwjH8O.js.map
