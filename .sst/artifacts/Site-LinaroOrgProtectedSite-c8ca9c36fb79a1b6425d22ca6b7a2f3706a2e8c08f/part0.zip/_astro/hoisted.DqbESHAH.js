import{_ as t}from"./preload-helper.ygWHROA3.js";const{signIn:i,signOut:e}=await t(()=>import("./client.BqElmF-z.js"),[]);document.getElementById("login");const o=document.getElementById("logout");o?.addEventListener("click",()=>{e()});
//# sourceMappingURL=hoisted.DqbESHAH.js.map
